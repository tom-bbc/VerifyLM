import json

from VerifyLM import VerifyLM

with open("credentials.json", "r") as file:
    CREDENTIALS = json.load(file)

GOOGLE_API_KEY = CREDENTIALS["google_api_key"]
OPENAI_API_KEY = CREDENTIALS["openai_api_key"]

verifylm = VerifyLM(GOOGLE_API_KEY, OPENAI_API_KEY)
output = verifylm.run("this is an example piece of text")
