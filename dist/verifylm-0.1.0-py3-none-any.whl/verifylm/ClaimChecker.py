import requests


class ClaimChecker:
    def __init__(self, google_fact_check_api_key: str) -> None:
        self.gfc_api_key = google_fact_check_api_key

        self.claim_language = "en"
        self.fact_check_api = "https://factchecktools.googleapis.com/v1alpha1/claims:search"

        self.rating_terms_mapping = {
            "Pants on Fire": "False",
            "One Pinocchio": "Mostly true: some omissions and exaggerations, but no outright falsehoods.",
            "Two Pinocchios": "Half true: significant omissions and/or exaggerations.",
            "Three Pinocchios": "Mostly false: significant factual error and/or obvious contradictions.",
            "Four Pinocchios": "False",
            "Geppetto Checkmark": "True",
            "Verdict Pending": "Verdict pending: judgement cannot be fully rendered",
        }

    def run(self, claims):
        # Parameters and variables
        params = {"key": self.gfc_api_key, "languageCode": self.claim_language, "query": ""}

        # Call Google Fact Check API to match input claim to known fact-checked claims
        for claim in claims:
            params["query"] = claim

            r = requests.get(url=self.fact_check_api, params=params)
            data = r.json()
            print(data)

        return []
