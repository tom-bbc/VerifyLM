from ClaimChecker import ClaimChecker
from ClaimDetector import ClaimDetector


class VerifyLM:
    def __init__(self, google_api_key: str, openai_api_key: str) -> None:
        self.openai_api_key = openai_api_key
        self.google_api_key = google_api_key

    def run(self, text: str):
        # Data structures & variables
        fact_checked_claims = []

        # Use OpenAI GPT model to detect & extract claims in the text
        # detector = ClaimDetector(self.openai_api_key)
        # detected_claims = detector.run(text)

        # Claim verification using Google Fact Check or Google search & OpenAI summary
        checker = ClaimChecker(self.google_api_key)
        fact_checked_claims = checker.run(["They're eating the dogs"])

        return fact_checked_claims
